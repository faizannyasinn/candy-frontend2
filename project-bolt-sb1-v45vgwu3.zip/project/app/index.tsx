import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useGame } from '@/contexts/GameContext';
import GradientButton from '@/components/GradientButton';

export default function HomeScreen() {
  const [createRoomName, setCreateRoomName] = useState('');
  const [joinRoomName, setJoinRoomName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [isJoining, setIsJoining] = useState(false);

  const { createRoom, joinRoom, state } = useGame();

  const handleCreateRoom = async () => {
    if (!createRoomName.trim()) {
      return;
    }

    setIsCreating(true);
    try {
      await createRoom(createRoomName.trim());
      router.push('/waiting-room');
    } catch (error) {
      console.error('Failed to create room:', error);
    } finally {
      setIsCreating(false);
    }
  };

  const handleJoinRoom = async () => {
    if (!joinRoomName.trim() || !roomCode.trim()) {
      return;
    }

    setIsJoining(true);
    try {
      await joinRoom(joinRoomName.trim(), roomCode.trim().toUpperCase());
      router.push('/poison-selection');
    } catch (error) {
      console.error('Failed to join room:', error);
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#FFE5E5', '#E5FFE5', '#E5E5FF']}
        style={styles.background}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}>
        
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.keyboardView}>
          
          <ScrollView
            contentContainerStyle={styles.scrollContent}
            showsVerticalScrollIndicator={false}>
            
            {/* Header */}
            <View style={styles.header}>
              <Text style={styles.title}>🍭 CandyBoard</Text>
              <Text style={styles.subtitle}>Multiplayer Poison Candy Game</Text>
              <Text style={styles.description}>
                Select your poison candy secretly, then take turns eating candies. 
                Don't eat your opponent's poison or you lose!
              </Text>
            </View>

            {/* Create Room Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Create Room</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your name"
                value={createRoomName}
                onChangeText={setCreateRoomName}
                maxLength={20}
                autoCapitalize="words"
                returnKeyType="done"
                placeholderTextColor="#999999"
              />
              <GradientButton
                title={isCreating ? "Creating..." : "Create Room"}
                onPress={handleCreateRoom}
                disabled={isCreating || !createRoomName.trim()}
                colors={['#FF6B9D', '#C44569']}
                style={styles.button}
              />
            </View>

            {/* Divider */}
            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>OR</Text>
              <View style={styles.dividerLine} />
            </View>

            {/* Join Room Section */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Join Room</Text>
              <TextInput
                style={styles.input}
                placeholder="Enter your name"
                value={joinRoomName}
                onChangeText={setJoinRoomName}
                maxLength={20}
                autoCapitalize="words"
                returnKeyType="next"
                placeholderTextColor="#999999"
              />
              <TextInput
                style={styles.input}
                placeholder="Enter room code"
                value={roomCode}
                onChangeText={(text) => setRoomCode(text.toUpperCase())}
                maxLength={6}
                autoCapitalize="characters"
                returnKeyType="done"
                placeholderTextColor="#999999"
              />
              <GradientButton
                title={isJoining ? "Joining..." : "Join Room"}
                onPress={handleJoinRoom}
                disabled={isJoining || !joinRoomName.trim() || !roomCode.trim()}
                colors={['#4ECDC4', '#44A08D']}
                style={styles.button}
              />
            </View>

            {/* Error Display */}
            {state.error && (
              <View style={styles.errorContainer}>
                <Text style={styles.errorText}>{state.error}</Text>
              </View>
            )}

          </ScrollView>
        </KeyboardAvoidingView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  background: {
    flex: 1,
  },
  keyboardView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 24,
    paddingVertical: 40,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Nunito-Bold',
    color: '#2C3E50',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    fontFamily: 'Nunito-SemiBold',
    color: '#7F8C8D',
    textAlign: 'center',
    marginBottom: 12,
  },
  description: {
    fontSize: 14,
    fontFamily: 'Nunito-Regular',
    color: '#95A5A6',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 20,
  },
  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 6,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Nunito-SemiBold',
    color: '#2C3E50',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    height: 48,
    borderWidth: 2,
    borderColor: '#E8E8E8',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
    fontSize: 16,
    fontFamily: 'Nunito-Regular',
    backgroundColor: '#FAFAFA',
    color: '#2C3E50',
  },
  button: {
    marginTop: 8,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#DDD',
  },
  dividerText: {
    marginHorizontal: 16,
    fontSize: 14,
    fontFamily: 'Nunito-SemiBold',
    color: '#999',
  },
  errorContainer: {
    backgroundColor: '#FFE5E5',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#FF6B9D',
  },
  errorText: {
    fontSize: 14,
    fontFamily: 'Nunito-Regular',
    color: '#C44569',
    textAlign: 'center',
  },
});